## Emacs: -*- coding: utf-8; fill-column: 62; comment-column: 27; -*-

###
### EXEMPLES DE CALCULS EN APPARENCE ERRONÉS
###

## Opérateurs d'addition et de soustraction ne respectant pas les
## règles d'arithmétique de base.
1.2 + 1.4 + 2.8            # 5.4
1.2 + 1.4 + 2.8 == 5.4     # non?!?
2.8 + 1.2 + 1.4            # encore 5.4
2.8 + 1.2 + 1.4 == 5.4     # donc addition non commutative?
2.6 - 1.4 - 1.2            # devrait donner 0
2.6 - 1.5 - 1.1            # correct cette fois-ci

## Division donnant parfois des résultats erronés.
0.2/0.1 == 2               # ok
(1.2 - 1.0)/0.1 == 2       # pourtant équivalent
0.3/0.1 == 3               # fonctionnait pourtant avec 0.2

## Distance plus grande entre 3,2 et 3,15 qu'entre 3,10 et
## 3,15.
3.2 - 3.15 > 0.05          # écart supérieur à 0,05...
3.15 - 3.1 < 0.05          # et cette fois inférieur à 0,05

## Valeurs inexactes dans les suites de nombres générées avec
## 'seq', qui sont générées algébriquement (par additions ou
## soustractions successives).
(a <- seq(0.9, 0.95, by = 0.01))
a == 0.94                  # 0.94 n'est pas dans le vecteur!
(b <- c(0.90, 0.91, 0.92, 0.93, 0.94, 0.95))
b == 0.94                  # mais ici, oui!
a - b                      # remarquer le 5e élément
